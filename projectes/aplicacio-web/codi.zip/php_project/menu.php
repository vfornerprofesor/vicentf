<link rel="stylesheet" href="styles/menu.css">

<div class="navbar">
        <div class="navbar_user">
            <p>Hello <?php echo $username; ?></p>
        </div>
        <div class="navbar_elements">
            <a href="#home">Home</a>
            <a href="#computers">Computers</a>
            <a href="#smartphones">Smartphones</a>
            <a href="#favourites"><i class="fa fa-heart"></i></a>
            <a href="#user"><i class="fa fa-user"></i></a>
            <a href="#cart"><i class="fa fa-shopping-cart"></i></a>
            <!--<div class="dropdown">
            <button class="dropbtn">Dropdown
                <i class="fa fa-caret-down"></i>
            </button>
            <div class="dropdown-content">
                <a href="#">Link 1</a>
                <a href="#">Link 2</a>
                <a href="#">Link 3</a>
            </div>
        </div>-->
        </div>
    </div>