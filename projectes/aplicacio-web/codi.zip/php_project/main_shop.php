<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Digital Shop</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css"
        integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <link rel="stylesheet" href="styles/styles.css">
    <link rel="stylesheet" href="styles/shop.css">
    <script src="scripts/scripts.js"></script>
</head>

<body>
    <?php
    // Retrieve parameters from URL
    if (isset($_GET['username'])) {
        $username = $_GET['username'];

        session_start();

        // Set session variables
        $_SESSION['username'] = $username;


    } else {
        header("Location: login.php?");
        exit();
    }

    ?>

    <?php
    include("menu.php");
    ?>
    <div id="main">

        <!-- FAVORITOS -->

        <!-- FILTROS -->

        <!-- TODOS PRODUCTOS -->
        <div id="products">
            <?php
            $ordenadores = [
                ["name" => "Ordenador 1", "img" => "assets/photos/ordenador1.jpg", "price" => 458],
                ["name" => "Ordenador 2", "img" => "assets/photos/ordenador2.jpg", "price" => 543],
                ["name" => "Ordenador 3", "img" => "assets/photos/ordenador3.jpg", "price" => 607],
                ["name" => "Ordenador 4", "img" => "assets/photos/ordenador4.jpg", "price" => 812],
                ["name" => "Ordenador 5", "img" => "assets/photos/ordenador5.jpg", "price" => 498],
                ["name" => "Ordenador 6", "img" => "assets/photos/ordenador6.jpg", "price" => 732],
                ["name" => "Ordenador 7", "img" => "assets/photos/ordenador7.jpg", "price" => 665],
                ["name" => "Ordenador 8", "img" => "assets/photos/ordenador8.jpg", "price" => 421],
                ["name" => "Ordenador 9", "img" => "assets/photos/ordenador9.jpg", "price" => 567],
                ["name" => "Ordenador 10", "img" => "assets/photos/ordenador10.jpg", "price" => 713],
                ["name" => "Ordenador 11", "img" => "assets/photos/ordenador11.jpg", "price" => 489],
                ["name" => "Ordenador 12", "img" => "assets/photos/ordenador12.jpg", "price" => 628],
                ["name" => "Ordenador 13", "img" => "assets/photos/ordenador13.jpg", "price" => 726],
                ["name" => "Ordenador 14", "img" => "assets/photos/ordenador14.jpg", "price" => 572],
                ["name" => "Ordenador 15", "img" => "assets/photos/ordenador15.jpg", "price" => 623]
            ];

            foreach ($ordenadores as $ordenador) {
                echo '<div class="product">';
                echo '<img src="' . $ordenador['img'] . '">';
                echo '<p class="product_name">' . $ordenador['name'] . '</p>';
                echo '<p class="product_price">' . $ordenador['price'] . '</p>';
                echo '</div>';
            }


            ?>
        </div>
    </div>

    <!-- PIE DE PÁGINA -->

</body>

</html>