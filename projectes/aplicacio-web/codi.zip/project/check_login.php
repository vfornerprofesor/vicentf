<?php
include('database.php');
$users = get_users();
$error = "";
$usercorrect = false;
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['fusername'];
    $password = $_POST['lpassword'];
    foreach ($users as $user) {

        if ($user['username'] == $username) {
            if ($user['password'] == $password) {
                $usercorrect = true;
            }
        }

    }
    if ($usercorrect) {
        session_start();
        $_SESSION['username'] = $username;
        header("Location: main_shop.php");
        exit();
    } else {
        $error = "User or password is wrong";
        header("Location: login.php?error=$error");
        exit();
    }
}

?>