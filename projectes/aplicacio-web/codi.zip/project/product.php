<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Digital Shop</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css"
        integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <link rel="stylesheet" href="styles/styles.css">
    <link rel="stylesheet" href="styles/product.css">
    <script src="scripts/scripts.js"></script>
</head>

<body>
    <?php
    session_start();
    $username = $_SESSION['username'];
    if (empty($username)) {
        header("Location: login.php");
        exit();
    }

    include('database.php');
    if ($_SERVER["REQUEST_METHOD"] == "GET") {
        $id = $_REQUEST['id'];
        $prod = get_product($id);
    }

    ?>

    <?php
    include("menu.php");
    ?>
    <div id="product">
        <div id="prod_img">
            <?php
                echo '<img src="' . $prod['img'] . '">';
            ?>
        </div>
        <div id="prod_info">
            <?php
                echo '<h1>' . $prod['name'] . '</h1>';
                echo '<img class="rating" src="assets/rating/' . $prod['rating'] . '.png">';
                echo '<p>' . $prod['description'] . '</p>';
                echo '<div id="prod_price">';
                echo '<p>' . $prod['price'] . '€</p>';
                echo '<a>Add to cart</a>';
                echo '</div>';
            ?>
        </div>
    </div>

       

</body>

</html>