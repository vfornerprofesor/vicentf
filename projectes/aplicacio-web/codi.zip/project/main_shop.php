<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Digital Shop</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css"
        integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <link rel="stylesheet" href="styles/styles.css">
    <link rel="stylesheet" href="styles/shop.css">
    <script src="scripts/scripts.js"></script>
</head>

<body>
    <?php
    session_start();
    $username = $_SESSION['username'];
    if (empty($username)) {
        header("Location: login.php");
        exit();
    }

    include('database.php');
    if ($_SERVER["REQUEST_METHOD"] == "GET") {
        $name = $_REQUEST['name'];
        $computers = $_REQUEST['computers'];
        $smartphones = $_REQUEST['smartphones'];
        $price_min = $_REQUEST['price_min'];
        $price_max = $_REQUEST['price_max'];

        if(empty($_GET)) {
            $computers = 'on';
            $smartphones = 'on';
            $price_min = 0;
            $price_max = 1000;
        }
        $products = get_products($name, $computers, $smartphones, $price_min, $price_max);
    }

    ?>

    <?php
    include("menu.php");
    ?>
    <div id="main">

        <!-- FAVORITOS -->

        <!-- FILTROS -->
        
        <div id="filters">
            <details>
                <summary>Filters</summary>
                <form action="main_shop.php" method="GET">
                    <fieldset>
                        <legend>Name</legend>
                        <?php
                        if ($name != "") {
                            echo '<input type="text" name="name" id="name" value="' . $name . '">';
                        } else {
                            echo '<input type="text" name="name" id="name">';
                        }
                        ?>
                    </fieldset>
                    <fieldset>
                        <legend>Category</legend>
                        <?php
                        if ($computers == "on") {
                            echo '<input type="checkbox" name="computers" id="computers" checked>';
                        } else {
                            echo '<input type="checkbox" name="computers" id="computers">';
                        }
                        ?>
                        <label for="computers">Computers</label>
                        <br>
                        <?php
                        if ($smartphones == "on") {
                            echo '<input type="checkbox" name="smartphones" id="smartphones" checked>';
                        } else {
                            echo '<input type="checkbox" name="smartphones" id="smartphones">';
                        }
                        ?>
                        <label for="smartphones">Smartphones</label>
                    </fieldset>
                    <fieldset>
                        <legend>Price</legend>
                        <label for="price_min">Minimum price</label>
                        <?php
                        if ($price_min != "") {
                            echo '<input type="range" name="price_min" id="price_min" value=' . $price_min . ' max=1000
                                oninput="this.nextElementSibling.value = this.value+' . "'€'" . '">';
                            echo '<output>' . $price_min . '€</output>';
                        } else {
                            ?>
                            <input type="range" name="price_min" id="price_min" value=0 min=0 max=1000
                                oninput="this.nextElementSibling.value = this.value+'€'">
                            <output>0€</output>
                            <?php
                        }
                        ?>
                        <br>
                        <label for="price_max">Maximum price</label>
                        <?php
                        if ($price_max != "") {
                            echo '<input type="range" name="price_max" id="price_max" value=' . $price_max . ' max=1000
                                oninput="this.nextElementSibling.value = this.value+' . "'€'" . '">';
                            echo '<output>' . $price_max . '€</output>';
                        } else {
                            ?>
                            <input type="range" name="price_max" id="price_max" value=1000 min=0 max=1000
                                oninput="this.nextElementSibling.value = this.value+'€'">
                            <output>1000€</output>
                            <?php
                        }
                        ?>
                    </fieldset>
                    <fieldset id="fieldset_filter">
                        <input type="submit" value="Filter">
                    </fieldset>
                </form>
            </details>
        </div>
      
      
        <!-- TODOS PRODUCTOS -->
        <div id="products">
            <?php
            foreach ($products as $prod) {
                echo '<a href="product.php?id=' . $prod['id'] . '">';
                echo '<div class="product">';
                echo '<img class="product_img" src="' . $prod['img'] . '">';
                echo '<div class="product_info">';
                echo '<p class="product_name">' . $prod['name'] . '</p>';
                echo '<p class="product_price">' . $prod['price'] . '€</p>';
                //echo '<a href="fav_add.php?id=3"><i class="fa fa-heart"></i></a>';
                echo '</div>';
                echo '</div>';
                echo '</a>';
            }


            ?>
        </div>
    </div>

    <!-- PIE DE PÁGINA -->

</body>

</html>