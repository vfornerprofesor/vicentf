<?php
include('database.php');
if ($_SERVER["REQUEST_METHOD"] == "GET") {
    $id_product = $_REQUEST['id'];
    if ($id_product) {
        $favourites[] = $id_product;
        foreach($favourites as $f) {
            echo "<p>$f</p>";
        }
    }
}
//header("Location: main_shop.php");
//exit();

?>