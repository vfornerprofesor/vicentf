<?php

$products = [
    ["id"=> 1,"name" => "Ordenador 1", "img" => "assets/photos/ordenador1.jpg", "price" => 458, "category" => "computers", "description" => "Computer with an intel CPU with last generation i5 model. Has 16GB of RAM and 512GB SSD of storage. It has a dedicated graphic card with 8GB. We can use it for gaming and it has led colors.", "rating" => 1],
    ["id"=> 2,"name" => "Ordenador 2", "img" => "assets/photos/ordenador2.jpg", "price" => 543, "category" => "computers", "description" => "Computer with an intel CPU with last generation i5 model. Has 16GB of RAM and 512GB SSD of storage. It has a dedicated graphic card with 8GB. We can use it for gaming and it has led colors.", "rating" => 5],
    ["id"=> 3,"name" => "Ordenador 3", "img" => "assets/photos/ordenador3.jpg", "price" => 607, "category" => "computers", "description" => "Computer with an intel CPU with last generation i5 model. Has 16GB of RAM and 512GB SSD of storage. It has a dedicated graphic card with 8GB. We can use it for gaming and it has led colors.", "rating" => 3],
    ["id"=> 4,"name" => "Ordenador 4", "img" => "assets/photos/ordenador4.jpg", "price" => 812, "category" => "computers", "description" => "Computer with an intel CPU with last generation i5 model. Has 16GB of RAM and 512GB SSD of storage. It has a dedicated graphic card with 8GB. We can use it for gaming and it has led colors.", "rating" => 2],
    ["id"=> 5,"name" => "Ordenador 5", "img" => "assets/photos/ordenador5.jpg", "price" => 498, "category" => "computers", "description" => "Computer with an intel CPU with last generation i5 model. Has 16GB of RAM and 512GB SSD of storage. It has a dedicated graphic card with 8GB. We can use it for gaming and it has led colors.", "rating" => 3],
    ["id"=> 6,"name" => "Ordenador 6", "img" => "assets/photos/ordenador6.jpg", "price" => 732, "category" => "computers", "description" => "Computer with an intel CPU with last generation i5 model. Has 16GB of RAM and 512GB SSD of storage. It has a dedicated graphic card with 8GB. We can use it for gaming and it has led colors.", "rating" => 4],
    ["id"=> 7,"name" => "Ordenador 7", "img" => "assets/photos/ordenador7.jpg", "price" => 665, "category" => "computers", "description" => "Computer with an intel CPU with last generation i5 model. Has 16GB of RAM and 512GB SSD of storage. It has a dedicated graphic card with 8GB. We can use it for gaming and it has led colors.", "rating" => 5],
    ["id"=> 8,"name" => "Ordenador 8", "img" => "assets/photos/ordenador8.jpg", "price" => 421, "category" => "computers", "description" => "Computer with an intel CPU with last generation i5 model. Has 16GB of RAM and 512GB SSD of storage. It has a dedicated graphic card with 8GB. We can use it for gaming and it has led colors.", "rating" => 5],
    ["id"=> 9,"name" => "Ordenador 9", "img" => "assets/photos/ordenador9.jpg", "price" => 567, "category" => "computers", "description" => "Computer with an intel CPU with last generation i5 model. Has 16GB of RAM and 512GB SSD of storage. It has a dedicated graphic card with 8GB. We can use it for gaming and it has led colors.", "rating" => 2],
    ["id"=> 10,"name" => "Smartphone 1", "img" => "assets/photos/smartphone1.jpg", "price" => 713, "category" => "smartphones", "description" => "Smartphone with Snapdragon processor and 8GB of RAM memory. It has also a 256GB of internal memory and very good camera.", "rating" => 1],
    ["id"=> 11,"name" => "Smartphone 2", "img" => "assets/photos/smartphone2.jpg", "price" => 628, "category" => "smartphones", "description" => "Smartphone with Snapdragon processor and 8GB of RAM memory. It has also a 256GB of internal memory and very good camera.", "rating" => 3],
    ["id"=> 12,"name" => "Smartphone 3", "img" => "assets/photos/smartphone3.jpg", "price" => 726, "category" => "smartphones", "description" => "Smartphone with Snapdragon processor and 8GB of RAM memory. It has also a 256GB of internal memory and very good camera.", "rating" => 2],
    ["id"=> 13,"name" => "Smartphone 4", "img" => "assets/photos/smartphone4.jpg", "price" => 572, "category" => "smartphones", "description" => "Smartphone with Snapdragon processor and 8GB of RAM memory. It has also a 256GB of internal memory and very good camera.", "rating" => 3],
    ["id"=> 14,"name" => "Smartphone 5", "img" => "assets/photos/smartphone5.jpg", "price" => 623, "category" => "smartphones", "description" => "Smartphone with Snapdragon processor and 8GB of RAM memory. It has also a 256GB of internal memory and very good camera.", "rating" => 4],
    ["id"=> 15,"name" => "Smartphone 6", "img" => "assets/photos/smartphone6.jpg", "price" => 489, "category" => "smartphones", "description" => "Smartphone with Snapdragon processor and 8GB of RAM memory. It has also a 256GB of internal memory and very good camera.", "rating" => 5],
];

$users = [
    [
        "username" => "vicent",
        "password" => "1234",
    ],
    [
        "username" => "pepe",
        "password" => "1111",
    ]
];

$favourites = [2, 5, 6];

function get_products($name, $computers, $smartphones, $price_min, $price_max) {
    global $products;
    $filtered = [];
    foreach($products as $p) {
        if(strpos($p['name'], $name) !== false || $name == "") {

            if(($computers == "on" && $p['category'] == 'computers') || $smartphones == "on" && $p['category'] == 'smartphones') {
                /* echo "<h1>" . $p['price'] . "</h1>";
                echo "<h1>" . $price_min . "</h1>";
                echo "<h1>" . $price_max . "</h1>"; */
                if($p['price'] >= $price_min && $p['price'] <= $price_max) {
                    $filtered[] = $p;
                }
            }
        }

    }
    return $filtered;
}

function get_product($id) {
    global $products;
    foreach($products as $p) {
        if($p['id'] == $id) return $p;
    }
    return null;
}

function get_users() {
    global $users;
    return $users;
}
?>