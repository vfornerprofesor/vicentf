function showPassword(id, eye_id) {
    pass = document.getElementById(id);
    eye = document.getElementById(eye_id);

    if(pass.type == 'text') {
        pass.type = 'password';
        eye.classList.remove('fa-eye');
        eye.classList.add('fa-eye-slash');
    } else {
        pass.type = 'text';
        eye.classList.add('fa-eye');
        eye.classList.remove('fa-eye-slash');
    }
}