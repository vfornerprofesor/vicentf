document.show_menu = false;
function showMenu() {
    document.show_menu = !document.show_menu;
    menu = document.getElementsByClassName('navbar_elements')[0];

    if(document.show_menu) {
        menu.classList.add('navbar_elements_show_menu');
    } else {
        menu.classList.remove('navbar_elements_show_menu');
    }

    for(let i = 0; i < menu.children.length; i++) {
        element = menu.children[i];
        if(!element.classList.contains('icon')) {
            if(document.show_menu) {
                element.classList.add('a_show_menu');
            } else {
                element.classList.remove('a_show_menu');
            }
        }
    }
}