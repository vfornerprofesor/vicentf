<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Task Manager</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <link rel="stylesheet" href="styles/styles.css">
    <script src="scripts/scripts.js"></script>
    <link rel="stylesheet" href="styles/login_signup.css">
</head>

<body>
    <div id="div_all">
        <h1>Sign up</h1>
        <div id="div_general">
            <img id="img_logo" src="assets/logo.jpg" alt="">
            <div id="div_form">
                <form action="/signup.php">
                    <label for="fname">Name</label><br>
                    <input class="input_text" type="text" id="fname" name="fname" value=""><br>
                    <label for="fsurname">Surname</label><br>
                    <input class="input_text" type="text" id="fsurname" name="fsurname" value=""><br>
                    <label for="fbirth">Birthdate</label><br>
                    <input class="input_text" type="date" id="fbirth" name="fbirth" value=""><br>
                    <label for="fusername">Username</label><br>
                    <input class="input_text" type="text" id="fusername" name="fusername" value=""><br>
                    <label for="lpassword">Password</label><br>
                    <input class="input_text" type="password" id="lpassword" name="lpassword" value="">
                    <i onclick="showPassword('lpassword', 'icon_eye')" id="icon_eye" class="fa fa-eye-slash"></i><br>
                    <label for="lpassword2">Repeat password</label><br>
                    <input class="input_text" type="password" id="lpassword2" name="lpassword2" value="">
                    <i onclick="showPassword('lpassword2', 'icon_eye2')" id="icon_eye2" class="fa fa-eye-slash"></i><br>
                    <label>Gender:</label>
                      <input type="radio" id="g_male" name="gender" value="Male">
                      <label for="g_male">Male</label>
                      <input type="radio" id="g_female" name="gender" value="Female">
                      <label for="g_female">Female</label>
                      <input type="radio" id="g_other" name="gender" value="Other">
                      <label for="g_other">Other</label>
                    
                    <input id="btn_submit" type="submit" value="Sign up">
                </form>
                <p id="text_signup">If you already have an account, please<a href="login.php">Log in</a></p>
                
            </div>
        </div>
    </div>
</body>

</html>