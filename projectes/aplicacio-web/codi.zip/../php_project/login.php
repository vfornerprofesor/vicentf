<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Task Manager</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css"
        integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <link rel="stylesheet" href="styles/styles.css">
    <script src="scripts/scripts.js"></script>
    <link rel="stylesheet" href="styles/login_signup.css">
</head>

<body>
    <?php
    $users = [
        [
            "username" => "vicent",
            "password" => "1234",
        ],
        [
            "username" => "pepe",
            "password" => "1111",
        ]
    ];
    $error = "";
    $usercorrect = false;
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $username = $_POST['fusername'];
        $password = $_POST['lpassword'];
        foreach ($users as $user) {

            if ($user['username'] == $username) {
                if ($user['password'] == $password) {
                    $usercorrect = true;
                }
            }

        }
        if ($usercorrect) {
            header("Location: main.php?username=$username");
            exit();
        } else {
            $error = "User or password is wrong";
        }
    }

    ?>
    <div id="div_all">
        <h1>Log in</h1>
        <div id="div_general">
            <img id="img_logo" src="assets/logo.jpg" alt="">
            <div id="div_form">
                <form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
                    <label for="fusername">Username</label><br>
                    <input class="input_text" type="text" id="fusername" name="fusername" value=""><br>
                    <label for="lpassword">Password</label><br>
                    <input class="input_text" type="password" id="lpassword" name="lpassword" value="">
                    <i onclick="showPassword('lpassword', 'icon-eye')" id="icon_eye" class="fa fa-eye-slash"></i><br>
                    <input type="checkbox" id="remember" name="remember">
                    <label for="remember">Remember password</label><br>
                    <input id="btn_submit" type="submit" value="Log in">
                </form>
                <?php
                if ($error != '') {
                    echo '<p id="error">'.$error.'</p>';
                }
                ?>
                <p id="text_signup">You don't have an account? Go to <a href="signup.php">Sign up</a></p>

            </div>
        </div>
    </div>
</body>

</html>