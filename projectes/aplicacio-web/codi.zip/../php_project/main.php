<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Task Manager</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css"
        integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <link rel="stylesheet" href="styles/styles.css">
    <script src="scripts/scripts.js"></script>
</head>

<body>
    <?php
    // Retrieve parameters from URL
    if (isset($_GET['username'])) {
        $username = $_GET['username'];

        session_start();

        // Set session variables
        $_SESSION['username'] = $username;

        // Display parameter values
        echo "<h1>Welcome, $username!</h1>";
    }

    $tasks = [
        [
            "name" => "Ordenador no arranca",
            "description" => "El ordenador no enciende cuando presiono el botón de encendido.",
            "date_in" => "15/01/2023",
            "state" => "assigned",
            "date_repaired" => ""
        ],
        [
            "name" => "Pantalla no muestra imagen",
            "description" => "La pantalla del ordenador está en blanco, no muestra ninguna imagen.",
            "date_in" => "10/02/2023",
            "state" => "repairing",
            "date_repaired" => ""
        ],
        [
            "name" => "Problemas de sonido",
            "description" => "No hay sonido proveniente de los altavoces del ordenador.",
            "date_in" => "25/02/2023",
            "state" => "repaired",
            "date_repaired" => "05/03/2023"
        ],
        [
            "name" => "Virus y malware",
            "description" => "El ordenador está infectado con virus y programas maliciosos.",
            "date_in" => "03/03/2023",
            "state" => "delivered",
            "date_repaired" => "10/03/2023"
        ],
        [
            "name" => "Problemas de conexión Wi-Fi",
            "description" => "No puedo conectarme a ninguna red Wi-Fi desde mi ordenador.",
            "date_in" => "12/03/2023",
            "state" => "assigned",
            "date_repaired" => ""
        ],
        [
            "name" => "Lentitud extrema",
            "description" => "Mi ordenador funciona extremadamente lento, incluso para tareas simples.",
            "date_in" => "18/03/2023",
            "state" => "repairing",
            "date_repaired" => ""
        ],
        [
            "name" => "Problemas con el teclado",
            "description" => "Algunas teclas de mi teclado no responden cuando las presiono.",
            "date_in" => "22/03/2023",
            "state" => "repaired",
            "date_repaired" => "02/04/2023"
        ],
        [
            "name" => "Problemas de sobrecalentamiento",
            "description" => "Mi ordenador se calienta demasiado y se apaga automáticamente.",
            "date_in" => "05/04/2023",
            "state" => "delivered",
            "date_repaired" => "12/04/2023"
        ],
        [
            "name" => "Problemas de hardware",
            "description" => "Mi ordenador muestra errores relacionados con el hardware en la pantalla.",
            "date_in" => "10/04/2023",
            "state" => "assigned",
            "date_repaired" => ""
        ],
        [
            "name" => "Problemas con el sistema operativo",
            "description" => "Mi sistema operativo muestra errores y se bloquea con frecuencia.",
            "date_in" => "15/04/2023",
            "state" => "repairing",
            "date_repaired" => ""
        ],
        [
            "name" => "Problemas con la tarjeta gráfica",
            "description" => "La pantalla muestra artefactos y colores extraños debido a problemas con la tarjeta gráfica.",
            "date_in" => "20/04/2023",
            "state" => "repaired",
            "date_repaired" => "28/04/2023"
        ],
        [
            "name" => "Problemas con el disco duro",
            "description" => "Mi ordenador no puede acceder a los datos almacenados en el disco duro.",
            "date_in" => "25/04/2023",
            "state" => "delivered",
            "date_repaired" => "02/05/2023"
        ]
    ];

    // Mostrar las tareas de reparación
    /*foreach ($tareasReparacion as $tarea) {
        echo "Nombre: " . $tarea["name"] . "<br>";
        echo "Descripción: " . $tarea["description"] . "<br>";
        echo "Fecha de entrada: " . $tarea["date_in"] . "<br>";
        echo "Estado: " . $tarea["state"] . "<br>";
        if (!empty($tarea["date_repaired"])) {
            echo "Fecha de reparación: " . $tarea["date_repaired"] . "<br>";
        }
        echo "<hr>";
    }*/
    ?>
    <h3>Look up your tasks</h3>
    <table id="table_tasks">
        <thead>
            <tr>
                <th>Name</th>
                <th>Description</th>
                <th>Registry date</th>
                <th>State</th>
                <th>Repaired date</th>
                <th>Open</th>
            </tr>
        </thead>
        <tbody>
            <?php

            foreach ($tasks as $task) {
                echo '<tr>';
                echo '<td>'.$task['name'].'</td>';
                echo '<td>'.$task['description'].'</td>';
                echo '<td>'.$task['date_in'].'</td>';
                echo '<td>'.$task['state'].'</td>';
                echo '<td>'.$task['date_repaired'].'</td>';
                echo '<td><i class="fa fa-folder-open-o"></i></td>';
                echo '</tr>';
            }
            ?>
        </tbody>
    </table>


</body>

</html>